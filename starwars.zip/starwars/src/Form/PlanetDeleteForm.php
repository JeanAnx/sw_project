<?php

namespace Drupal\starwars\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Planet entities.
 *
 * @ingroup starwars
 */
class PlanetDeleteForm extends ContentEntityDeleteForm {


}
