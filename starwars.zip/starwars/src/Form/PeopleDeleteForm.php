<?php

namespace Drupal\starwars\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting People entities.
 *
 * @ingroup starwars
 */
class PeopleDeleteForm extends ContentEntityDeleteForm {


}
