<?php

namespace Drupal\starwars\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Starship entities.
 *
 * @ingroup starwars
 */
class StarshipDeleteForm extends ContentEntityDeleteForm {


}
