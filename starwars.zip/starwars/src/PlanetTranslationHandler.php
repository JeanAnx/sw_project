<?php

namespace Drupal\starwars;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for starwars_planet.
 */
class PlanetTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.

}
